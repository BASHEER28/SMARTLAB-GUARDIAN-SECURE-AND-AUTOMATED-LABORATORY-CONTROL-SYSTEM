//keypad.h
#include "types.h"
/* Function: initkpm; void are used as the function inputs. */
void initkpm(void);
/* Function: colscan; void are used as the function inputs. */
int colscan(void);
/* Function: rowcheck; void are used as the function inputs. */
u8 rowcheck(void);
/* Function: colcheck; void are used as the function inputs. */
u8 colcheck(void);
/* Function: keyscan; void are used as the function inputs. */
u8 keyscan(void);
/* Function: ReadNum; void are used as the function inputs. */
u32 ReadNum(void);
/* Function: Readnum2; u32 *,u8 * are used as the function inputs. */
void Readnum2(u32 *,u8 *);
/* Function: password; u32  are used as the function inputs. */
u32 password(u32 );
