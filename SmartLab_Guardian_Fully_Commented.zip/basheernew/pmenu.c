//MENU.c

#include <LPC214x.h>
#include "headerfiles.h"
#include "keypad.h"
#include "keypaddefines.h"
#include "types.h"
#include "lcd.h"
#include "LCD_defines.h"
#include "rtc.h"
#include "menu.h"
#include "delay.h"

/* Access the RTC register or schedule field used by the time/date logic. */
u32 ON_HOUR = 6;
/* Access the RTC register or schedule field used by the time/date logic. */
u32 ON_MIN = 0;

/* Access the RTC register or schedule field used by the time/date logic. */
u32 OFF_HOUR = 9;
/* Access the RTC register or schedule field used by the time/date logic. */
u32 OFF_MIN = 59;

/* Function: Menu; void are used as the function inputs. */
void Menu(void)
{	
	/* Repeat this block while the stated condition remains true. */
	while(1)
	/* Perform the operation required at this point in the routine. */
	{ u32 choice;
		/* Send the specified instruction to the LCD controller. */
		Cmdlcd(CLEAR_LCD);
	/* Display the supplied null-terminated string on the LCD. */
	Strlcd("1.TIME  2.DATE");
	/* Send the specified instruction to the LCD controller. */
	Cmdlcd(GOTO_LINE2_POS0);
	/* Display the supplied null-terminated string on the LCD. */
	Strlcd("3.LABTIME 4.EXT");
		
		/* Read the keypad state / decoded key from the matrix keypad driver. */
		choice =keyscan()-48;
		/* Evaluate the condition and execute this branch only when it is true. */
		if(choice == 1)
		{
			/* Perform the operation required at this point in the routine. */
			rtcedit();
			/* Send the specified instruction to the LCD controller. */
			Cmdlcd(CLEAR_LCD);
				/* Display the supplied null-terminated string on the LCD. */
				Strlcd("TIME UPDATED");
				/* Perform the operation required at this point in the routine. */
				showtime();
			/* Wait for the peripheral settling / user-interface interval required here. */
			delay_ms(1000);
    }
		/* Test the next mutually exclusive condition when earlier conditions did not match. */
		else if(choice == 2)
    {
			/* Perform the operation required at this point in the routine. */
			date1();
			/* Send the specified instruction to the LCD controller. */
			Cmdlcd(CLEAR_LCD);
				/* Display the supplied null-terminated string on the LCD. */
				Strlcd("DATE UPDATED");
				/* Perform the operation required at this point in the routine. */
				displaydate();
				/* Wait for the peripheral settling / user-interface interval required here. */
				delay_ms(1000);
		}
		
		/* Test the next mutually exclusive condition when earlier conditions did not match. */
		else if(choice == 3)
		{
		  /* Perform the operation required at this point in the routine. */
		  labtimeedit();
				/* Send the specified instruction to the LCD controller. */
				Cmdlcd(CLEAR_LCD);
				/* Display the supplied null-terminated string on the LCD. */
				Strlcd("SCHEDULE UPDATED");
				/* Wait for the peripheral settling / user-interface interval required here. */
				delay_ms(500);
		}
		/* Test the next mutually exclusive condition when earlier conditions did not match. */
		else if(choice==4)
		{ 
			/* Send the specified instruction to the LCD controller. */
			Cmdlcd(CLEAR_LCD);
			/* Change the current control-flow path as required by this branch. */
			break;
		}
		/* Handle the remaining case when no preceding condition matched. */
		else
		{
			/* Send the specified instruction to the LCD controller. */
			Cmdlcd(CLEAR_LCD);
			/* Display the supplied null-terminated string on the LCD. */
			Strlcd("INVALID OPTION");
			/* Wait for the peripheral settling / user-interface interval required here. */
			delay_ms(500);
		}
	}
}
