#include<LPC214x.h>
#include "headerfiles.h"
#include "device_control.h"
#include "rtc.h"
/* Declare shared or specially qualified state used across application execution contexts. */
volatile int flag=0;
/* Declare shared or specially qualified state used across application execution contexts. */
volatile int flag1=0;
main()
/* Update the variable with the newly calculated or entered value. */
{  u32 addr,command,toggle,temp=0,temp1=0,rtc_flag=0;
    /* Perform the operation required at this point in the routine. */
    initlcd();
    /* Perform the operation required at this point in the routine. */
    initkpm();
    /* Perform the operation required at this point in the routine. */
    initLED();
    /* Perform the operation required at this point in the routine. */
    initRTC();
	/* Perform the operation required at this point in the routine. */
	Init_Interrupt();
	/* Process or compare the keypad-entered access credential. */
	passwordchecking();
	/* Send the specified instruction to the LCD controller. */
	Cmdlcd(CLEAR_LCD);
    /* Repeat this block while the stated condition remains true. */
    while(1)
    { 	
      /* Evaluate the condition and execute this branch only when it is true. */
      if((Islabtime()))
        {   
			/* Perform the operation required at this point in the routine. */
			devicestatus(temp,temp1);
				/* Repeat this block while the stated condition remains true. */
				while((readrc5(&addr,&command,&toggle)==0))
				{  
					  /* Evaluate the condition and execute this branch only when it is true. */
					  if(rtc_flag==0)
					    /* Perform the operation required at this point in the routine. */
					    {showtime();
						 	/* Send the specified instruction to the LCD controller. */
						 	Cmdlcd(GOTO_LINE2_POS0);
	                        /* Display the supplied null-terminated string on the LCD. */
	                        Strlcd("lab is opened  ");
						}
					/* Evaluate the condition and execute this branch only when it is true. */
					if(flag)
					{
						/* Update the variable with the newly calculated or entered value. */
						flag=0;
						/* Perform the operation required at this point in the routine. */
						Menu();
						/* Update the variable with the newly calculated or entered value. */
						flag1=0;
						/* Evaluate the condition and execute this branch only when it is true. */
						if(Islabtime())
						/* Perform the operation required at this point in the routine. */
						devicestatus(temp,temp1);
						/* Handle the remaining case when no preceding condition matched. */
						else
						/* Change the current control-flow path as required by this branch. */
						break;
					}
					/* Evaluate the condition and execute this branch only when it is true. */
					if(flag1)
					/* Update the variable with the newly calculated or entered value. */
					{	   flag1=0;
					 /* Perform the operation required at this point in the routine. */
					 extinterrupt();
					    /* Update the variable with the newly calculated or entered value. */
					    temp=0,temp1=0;
						/* Evaluate the condition and execute this branch only when it is true. */
						if(Islabtime())
						/* Perform the operation required at this point in the routine. */
						devicestatus(temp,temp1);
						/* Handle the remaining case when no preceding condition matched. */
						else
						/* Change the current control-flow path as required by this branch. */
						break;
					}  
				}
		     /* Receive or apply the decoded remote-control command to the output devices. */
		     DeviceCntrl(command,&temp,&temp1);
			 /* Update the variable with the newly calculated or entered value. */
			 command=0;
			 /* Evaluate the condition and execute this branch only when it is true. */
			 if(rtc_flag==0)
			 {
			 /* Send the specified instruction to the LCD controller. */
			 Cmdlcd(GOTO_LINE1_POS0);
			 /* Display the supplied null-terminated string on the LCD. */
			 Strlcd("              ");
			 /* Update the variable with the newly calculated or entered value. */
			 rtc_flag=1;
			 }
			 /* Update the variable with the newly calculated or entered value. */
			 rtc_flag=1;
			 	/* Perform the operation required at this point in the routine. */
			 	devicestatus(temp,temp1);
			 }								
       /* Handle the remaining case when no preceding condition matched. */
       else
        {
            /* Perform the operation required at this point in the routine. */
            AllLEDsOFF();
	
            /* Send the specified instruction to the LCD controller. */
            E :Cmdlcd(0xC0);
            /* Display the supplied null-terminated string on the LCD. */
            Strlcd("Lab Closed      ");
					/* Repeat this block while the stated condition remains true. */
					while(Islabtime()==0)
					/* Perform the operation required at this point in the routine. */
					{  showtime();
						/* Evaluate the condition and execute this branch only when it is true. */
						if(flag)
						{
							/* Update the variable with the newly calculated or entered value. */
							flag=0;
							/* Perform the operation required at this point in the routine. */
							Menu();
							/* Update the variable with the newly calculated or entered value. */
							flag1=0;
							/* Evaluate the condition and execute this branch only when it is true. */
							if(Islabtime())
						/* Perform the operation required at this point in the routine. */
						devicestatus(temp,temp1);
						/* Handle the remaining case when no preceding condition matched. */
						else
						   /* Change the current control-flow path as required by this branch. */
						   goto E;
						}
                      }
					  /* Send the specified instruction to the LCD controller. */
					  Cmdlcd(CLEAR_LCD);
					  /* Send the specified instruction to the LCD controller. */
					  Cmdlcd(0x80);
                   /* Display the supplied null-terminated string on the LCD. */
                   Strlcd("Lab is now open");
			         /* Wait for the peripheral settling / user-interface interval required here. */
			         delay_ms(100);
    }	 
}	
}

