//rtc.h
#include "types.h"
/* Function: initRTC; void are used as the function inputs. */
void initRTC(void);
/* Function: Islabtime; void are used as the function inputs. */
u32 Islabtime(void);
/* Function: labtimecheck; void are used as the function inputs. */
void labtimecheck(void);
/* Function: showtime; void are used as the function inputs. */
void showtime(void);
/* Function: displaydate; void are used as the function inputs. */
void displaydate(void);
/* Function: rtcedit; void are used as the function inputs. */
void rtcedit(void);
/* Function: date1; void are used as the function inputs. */
void date1(void);
/* Function: labtimeedit; void are used as the function inputs. */
void labtimeedit(void);
/* Function: RTC_SetDate; u32,u32,u32,u32 are used as the function inputs. */
void RTC_SetDate(u32,u32,u32,u32);
/* Function: RTC_SetTime; u32,u32,u32 are used as the function inputs. */
void RTC_SetTime(u32,u32,u32);
#define FOSC          12000000         //frequency os system
#define CCLK          FOSC*5           //CPU opearating clock freq
#define PCLK          CCLK/4           //pheripharals opearating clock freq
#define PRE_INT_FREQ  (PCLK/32768)-1      //prescale register convet pclk to rtc clk freq(32.768KHZ).it gives approx value 
#define PRE_FRAC_FREQ \
PCLK-((PRE_INT_FREQ+1)*32768)  //prescale register convet pclk to rtc clk freq.it gives exact value with fraction also





