//menu.h

#include "types.h"

/* Access the RTC register or schedule field used by the time/date logic. */
extern u32 ON_HOUR;
/* Access the RTC register or schedule field used by the time/date logic. */
extern u32 ON_MIN;
/* Access the RTC register or schedule field used by the time/date logic. */
extern u32 OFF_HOUR;
/* Access the RTC register or schedule field used by the time/date logic. */
extern u32 OFF_MIN;

/* Function: Menu; void are used as the function inputs. */
void Menu(void);


