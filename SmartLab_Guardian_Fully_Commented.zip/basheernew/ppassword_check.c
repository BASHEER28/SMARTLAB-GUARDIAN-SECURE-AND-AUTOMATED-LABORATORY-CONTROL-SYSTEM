//passwordcheck.c
#include"headerfiles.h"
#include<LPC214x.h>
/* Function: passwordcheck; void are used as the function inputs. */
int passwordcheck(void)
{
    /* Declare local state used by this routine. */
    u32 pass;
          /* Send the specified instruction to the LCD controller. */
          Cmdlcd(CLEAR_LCD);
			    /* Send the specified instruction to the LCD controller. */
			    Cmdlcd(GOTO_LINE1_POS0);
          /* Display the supplied null-terminated string on the LCD. */
          Strlcd("Enter Password");
			   /* Process or compare the keypad-entered access credential. */
			   pass=password(PASSWORD_LEN);
         /* Send the specified instruction to the LCD controller. */
         Cmdlcd(CLEAR_LCD);
        /* Evaluate the condition and execute this branch only when it is true. */
        if (pass== PASSWORD)
				{
					/* Return the computed result to the calling function. */
					return 1;
				}
        /* Handle the remaining case when no preceding condition matched. */
        else
        { 
					/* Return the computed result to the calling function. */
					return 0;
				}
    }
/* Function: passwordchecking; void are used as the function inputs. */
void passwordchecking(void)
{
	/* Repeat this block while the stated condition remains true. */
	while(1)
	{
	       /* Evaluate the condition and execute this branch only when it is true. */
	       if(passwordcheck())
            {
                /* Send the specified instruction to the LCD controller. */
                Cmdlcd(CLEAR_LCD);
				/* Send the specified instruction to the LCD controller. */
				Cmdlcd(GOTO_LINE1_POS0);
                /* Display the supplied null-terminated string on the LCD. */
                Strlcd("WELCM TO SMART");
				/* Send the specified instruction to the LCD controller. */
				Cmdlcd(GOTO_LINE2_POS0);
				/* Display the supplied null-terminated string on the LCD. */
				Strlcd("GUARDIAN");
                /* Wait for the peripheral settling / user-interface interval required here. */
                delay_ms(500);
							/* Change the current control-flow path as required by this branch. */
							break;
            }
          /* Handle the remaining case when no preceding condition matched. */
          else
            {
                /* Send the specified instruction to the LCD controller. */
                Cmdlcd(CLEAR_LCD);
                /* Display the supplied null-terminated string on the LCD. */
                Strlcd("Wrong Password");
                /* Wait for the peripheral settling / user-interface interval required here. */
                delay_ms(500);
            }
	}
}


