//LCD.h

#include "types.h"
/* Function: initlcd; void are used as the function inputs. */
void initlcd(void);
/* Function: Writelcd; u8 dat are used as the function inputs. */
void Writelcd(u8 dat);
/* Function: Cmdlcd; u8 cmd are used as the function inputs. */
void Cmdlcd(u8 cmd);
/* Function: Charlcd; u8 asciival are used as the function inputs. */
void Charlcd(u8 asciival);
/* Function: Initlcd; void are used as the function inputs. */
void Initlcd(void);
/* Function: Strlcd; s8 * are used as the function inputs. */
void Strlcd(s8 *);
/* Function: u32lcd; u32 are used as the function inputs. */
void u32lcd(u32);
/* Function: s32lcd; s32 are used as the function inputs. */
void s32lcd(s32);
/* Function: f32lcd; f32,u8 are used as the function inputs. */
void f32lcd(f32,u8);
/* Function: BuildCGRAM; u8*,u8 are used as the function inputs. */
void BuildCGRAM(u8*,u8);
