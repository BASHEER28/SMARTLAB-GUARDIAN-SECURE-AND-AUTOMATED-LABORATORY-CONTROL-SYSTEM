//macros.h
#define WRITEBYTE(WORD,STBIT,BYTE) \
/* Update the variable with the newly calculated or entered value. */
WORD=((WORD&~(0xFF<<STBIT))|((BYTE)<<STBIT))
#define READBIT(WORD,BIT) ((WORD>>BIT)&1)
