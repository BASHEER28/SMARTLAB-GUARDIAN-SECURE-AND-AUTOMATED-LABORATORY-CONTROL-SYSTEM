//INT.c

#include <LPC214x.h>
#include "headerfiles.h"
#include "types.h"
#include "externalswitches.h"
#include "LCD_defines.h"
/* Declare shared or specially qualified state used across application execution contexts. */
extern volatile int flag;
/* Declare shared or specially qualified state used across application execution contexts. */
extern volatile int flag1;
/* Function: EINT0_ISR; void are used as the function inputs. */
void EINT0_ISR(void)__irq
/* Update the variable with the newly calculated or entered value. */
{  flag=1;
	//Menu();
	/* Configure or acknowledge the interrupt controller / external interrupt source. */
	EXTINT =1<<0;
	/* Configure or acknowledge the interrupt controller / external interrupt source. */
	VICVectAddr = 0;
}

/* Function: Init_Interrupt; void are used as the function inputs. */
void Init_Interrupt(void)
{ //for rtc
	/* Select the alternate pin function required by this peripheral. */
	PINSEL0 &= ~(3 << 2);
	/* Select the alternate pin function required by this peripheral. */
	PINSEL0 |= 0x0000000C;
	//for emergency
	/* Select the alternate pin function required by this peripheral. */
	PINSEL1&=~(3<<28);
	/* Select the alternate pin function required by this peripheral. */
	PINSEL1|=(2<<28);
	
	//VICIntSelect|=1<<EINT3_VIC_CHNO;//set fiq
	VICIntEnable |= (1 << 14)|(1<<17);//enable ent0 and ent3
	
	/* Configure or acknowledge the interrupt controller / external interrupt source. */
	VICVectCntl0 = (1 << 5) | 14;
	/* Configure or acknowledge the interrupt controller / external interrupt source. */
	VICVectAddr0 = (unsigned)EINT0_ISR;
	/* Configure or acknowledge the interrupt controller / external interrupt source. */
	VICVectCntl1 = (1 << 5) | 17;
	/* Configure or acknowledge the interrupt controller / external interrupt source. */
	VICVectAddr1 = (unsigned)EINT3_ISR;
	

//	IODIR0 &= ~(1 << 1);

	EXTMODE |= (1<<0)|(1<<3);//set edge trigger
	//EXTPOLAR=0;default is falling edge
}
/* Function: EINT3_ISR; void are used as the function inputs. */
void EINT3_ISR(void)__irq
	{
	/* Update the variable with the newly calculated or entered value. */
	flag1=1;
	/* Configure or acknowledge the interrupt controller / external interrupt source. */
	EXTINT=1<<3;
		/* Configure or acknowledge the interrupt controller / external interrupt source. */
		VICVectAddr=0;
}
/* Function: extinterrupt; void are used as the function inputs. */
void extinterrupt(void)
/* Send the specified instruction to the LCD controller. */
{	Cmdlcd(CLEAR_LCD);
	/* Display the supplied null-terminated string on the LCD. */
	Strlcd("EMERGENCY ALERT");
	/* Send the specified instruction to the LCD controller. */
	Cmdlcd(GOTO_LINE2_POS0);
	/* Display the supplied null-terminated string on the LCD. */
	Strlcd("TURN OFF ALL");
	/*IOCLR1=LED1;
	/* Drive the selected GPIO output bit(s) HIGH (IOSET) or LOW (IOCLR). */
	IOCLR1=LED2;*/
	/* Drive the selected GPIO output bit(s) HIGH (IOSET) or LOW (IOCLR). */
	IOSET1=BUZZER;
	/* Drive the selected GPIO output bit(s) HIGH (IOSET) or LOW (IOCLR). */
	IOCLR1=LED1;
	/* Drive the selected GPIO output bit(s) HIGH (IOSET) or LOW (IOCLR). */
	IOCLR1=LED2;
	/* Wait for the peripheral settling / user-interface interval required here. */
	delay_ms(3000);
	/* Evaluate the condition and execute this branch only when it is true. */
	if(!(Islabtime()))
	{
	/* Send the specified instruction to the LCD controller. */
	Cmdlcd(GOTO_LINE1_POS0);
	/* Display the supplied null-terminated string on the LCD. */
	Strlcd("lab closed      ");
	}
	/* Handle the remaining case when no preceding condition matched. */
	else
	 {
	/* Send the specified instruction to the LCD controller. */
	Cmdlcd(GOTO_LINE2_POS0);
	/* Display the supplied null-terminated string on the LCD. */
	Strlcd("Lab is opened   ");
	}
	/* Drive the selected GPIO output bit(s) HIGH (IOSET) or LOW (IOCLR). */
	IOCLR1=BUZZER;
}

