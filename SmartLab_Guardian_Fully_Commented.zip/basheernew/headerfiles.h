//header file inclusion
#include<LPC214x.h>
#include "LCD_defines.h"
#include "lcd.h"
#include "delay.h"
#include "types.h"
#include "rtc.h"
#include "keypad.h"
#include "keypaddefines.h"
#include "menu.h"
#include "password.h"
#include "tsop_rc5.h"
#include "externalswitches.h"
#define LED1 (1<<24)
#define LED2 (1<<25)
#define LED_MASK (LED1|LED2)
#define BUZZER (1<<26)

#define PASSWORD       4444
#define PASSWORD_LEN   4

//extern u32 temp;
//extern u32 temp1;

/* Declare shared or specially qualified state used across application execution contexts. */
extern u32 addr;
/* Declare shared or specially qualified state used across application execution contexts. */
extern u32 command;
/* Declare shared or specially qualified state used across application execution contexts. */
extern u32 toggle; 

