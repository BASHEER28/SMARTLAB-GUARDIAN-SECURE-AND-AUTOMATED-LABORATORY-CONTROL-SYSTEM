//externalswitches.h
/* Function: Init_Interrupt; void are used as the function inputs. */
void Init_Interrupt(void);
/* Function: EINT3_ISR; void are used as the function inputs. */
void EINT3_ISR(void)__irq;
/* Function: EINT0_ISR; void are used as the function inputs. */
void EINT0_ISR(void)__irq;

#define EINT0_PIN_0_1 0
#define EINT0_PIN_FUNC 0x0000000C
#define EINT0_VIC_CHNO 14

#define EINT3_PIN_0_9 0
#define EINT3_PIN_FUNC 0x25400000
#define EINT3_VIC_CHNO 17

/*definitions for input devics such as switche's
#define EMERG_SW		1
#define RTC_SW      6*/

