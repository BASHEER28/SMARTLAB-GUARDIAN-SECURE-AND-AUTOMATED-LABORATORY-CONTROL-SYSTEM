#include "types.h"
#include "headerfiles.h"
/* Function: rtcedit; void are used as the function inputs. */
void rtcedit(void)
/* Perform the operation required at this point in the routine. */
{ u32 choice;
        /* Declare local state used by this routine. */
        u32 hour, minute, second;
        /* Repeat this block while the stated condition remains true. */
        while(1)
        {
                /* Send the specified instruction to the LCD controller. */
                Cmdlcd(CLEAR_LCD);
        /* Access the RTC register or schedule field used by the time/date logic. */
        Strlcd("1.HOUR  2.MIN");
        /* Send the specified instruction to the LCD controller. */
        Cmdlcd(GOTO_LINE2_POS0);
        /* Access the RTC register or schedule field used by the time/date logic. */
        Strlcd("3.SEC  4.EXT");

                /* Read the keypad state / decoded key from the matrix keypad driver. */
                choice =keyscan()-48;
        /* Evaluate the condition and execute this branch only when it is true. */
        if(choice==1)
        {
Hour:
                        /* Send the specified instruction to the LCD controller. */
                        Cmdlcd(CLEAR_LCD);
                        /* Access the RTC register or schedule field used by the time/date logic. */
                        Strlcd("ENTER HOUR");
                        /* Update the variable with the newly calculated or entered value. */
                        hour = ReadNum();
                        /* Evaluate the condition and execute this branch only when it is true. */
                        if(hour > 24)
                        {
                                /* Send the specified instruction to the LCD controller. */
                                Cmdlcd(CLEAR_LCD);
                                /* Access the RTC register or schedule field used by the time/date logic. */
                                Strlcd("INVALID HOUR");
                                /* Wait for the peripheral settling / user-interface interval required here. */
                                delay_ms(500);
                                /* Change the current control-flow path as required by this branch. */
                                goto Hour;
                        }
                        /* Access the RTC register or schedule field used by the time/date logic. */
                        HOUR=hour;
                }
        /* Test the next mutually exclusive condition when earlier conditions did not match. */
        else if(choice==2)
        {
                        Minute:
                        /* Send the specified instruction to the LCD controller. */
                        Cmdlcd(CLEAR_LCD);
                        /* Access the RTC register or schedule field used by the time/date logic. */
                        Strlcd("ENTER MINUTE");
                        /* Update the variable with the newly calculated or entered value. */
                        minute = ReadNum();
                        /* Evaluate the condition and execute this branch only when it is true. */
                        if(minute > 60)
                        {
                                /* Send the specified instruction to the LCD controller. */
                                Cmdlcd(CLEAR_LCD);
                                /* Access the RTC register or schedule field used by the time/date logic. */
                                Strlcd("INVALID MINUTE");
                                /* Wait for the peripheral settling / user-interface interval required here. */
                                delay_ms(500);
                                /* Change the current control-flow path as required by this branch. */
                                goto Minute;
                        }
                        /* Access the RTC register or schedule field used by the time/date logic. */
                        MIN=minute;
                }
  /* Test the next mutually exclusive condition when earlier conditions did not match. */
  else if(choice==3)
        {
                        Second:
                        /* Send the specified instruction to the LCD controller. */
                        Cmdlcd(CLEAR_LCD);
                        /* Access the RTC register or schedule field used by the time/date logic. */
                        Strlcd("ENTER SECOND");
                         /* Update the variable with the newly calculated or entered value. */
                         second=ReadNum();
                        /* Evaluate the condition and execute this branch only when it is true. */
                        if(second > 60)
                        {
                                /* Send the specified instruction to the LCD controller. */
                                Cmdlcd(CLEAR_LCD);
                                /* Access the RTC register or schedule field used by the time/date logic. */
                                Strlcd("INVALID SECOND");
                                /* Wait for the peripheral settling / user-interface interval required here. */
                                delay_ms(500);
                                /* Change the current control-flow path as required by this branch. */
                                goto Second;
                        }
                        /* Access the RTC register or schedule field used by the time/date logic. */
                        SEC=second;
                }
        /* Test the next mutually exclusive condition when earlier conditions did not match. */
        else if(choice==4)
                /* Return the computed result to the calling function. */
                return;
        /* Handle the remaining case when no preceding condition matched. */
        else
        {
                /* Send the specified instruction to the LCD controller. */
                Cmdlcd(CLEAR_LCD);
                                /* Display the supplied null-terminated string on the LCD. */
                                Strlcd("invalid option");
                /* Wait for the peripheral settling / user-interface interval required here. */
                delay_ms(100);
        }
}
}
/* Function: date1; void are used as the function inputs. */
void date1(void)
/* Perform the operation required at this point in the routine. */
{ u32 date,month,year,choice;
        /* Repeat this block while the stated condition remains true. */
        while(1)
        {
                /* Send the specified instruction to the LCD controller. */
                Cmdlcd(CLEAR_LCD);
        /* Access the RTC register or schedule field used by the time/date logic. */
        Strlcd("1.DATE 2.MONTH");
        /* Send the specified instruction to the LCD controller. */
        Cmdlcd(GOTO_LINE2_POS0);
        /* Access the RTC register or schedule field used by the time/date logic. */
        Strlcd("3.YEAR  4.EXT");
                /* Read the keypad state / decoded key from the matrix keypad driver. */
                choice=keyscan()-48;
                /* Evaluate the condition and execute this branch only when it is true. */
                if(choice==1)
                {
        Date:
                        /* Send the specified instruction to the LCD controller. */
                        Cmdlcd(CLEAR_LCD);
                        /* Display the supplied null-terminated string on the LCD. */
                        Strlcd("ENTER DATE");
                        /* Update the variable with the newly calculated or entered value. */
                        date = ReadNum();
                        /* Evaluate the condition and execute this branch only when it is true. */
                        if(date > 31)
                        {
                                /* Send the specified instruction to the LCD controller. */
                                Cmdlcd(CLEAR_LCD);
                                /* Display the supplied null-terminated string on the LCD. */
                                Strlcd("INVALID DATE");
                                /* Wait for the peripheral settling / user-interface interval required here. */
                                delay_ms(500);
                                /* Change the current control-flow path as required by this branch. */
                                goto Date;
                        }
                        /* Access the RTC register or schedule field used by the time/date logic. */
                        DOM=date;
                }
                /* Test the next mutually exclusive condition when earlier conditions did not match. */
                else if(choice==2)
                {
                        Month:
                        /* Send the specified instruction to the LCD controller. */
                        Cmdlcd(CLEAR_LCD);
                        /* Access the RTC register or schedule field used by the time/date logic. */
                        Strlcd("ENTER MONTH");
                        /* Update the variable with the newly calculated or entered value. */
                        month = ReadNum();
                        /* Evaluate the condition and execute this branch only when it is true. */
                        if(month > 12)
                        {
                                /* Send the specified instruction to the LCD controller. */
                                Cmdlcd(CLEAR_LCD);
                                /* Access the RTC register or schedule field used by the time/date logic. */
                                Strlcd("INVALID MONTH");
                                /* Wait for the peripheral settling / user-interface interval required here. */
                                delay_ms(500);
                                /* Change the current control-flow path as required by this branch. */
                                goto Month;
                        }
                        /* Access the RTC register or schedule field used by the time/date logic. */
                        MONTH=month;
                }
                /* Test the next mutually exclusive condition when earlier conditions did not match. */
                else if(choice==3)
                {

                        Year:
                        /* Send the specified instruction to the LCD controller. */
                        Cmdlcd(CLEAR_LCD);
                        /* Access the RTC register or schedule field used by the time/date logic. */
                        Strlcd("ENTER YEAR");
                        /* Update the variable with the newly calculated or entered value. */
                        year = ReadNum();
                        /* Evaluate the condition and execute this branch only when it is true. */
                        if(year > 4096)
                        {
                                /* Send the specified instruction to the LCD controller. */
                                Cmdlcd(CLEAR_LCD);
                                /* Access the RTC register or schedule field used by the time/date logic. */
                                Strlcd("INVALID YEAR");
                                /* Wait for the peripheral settling / user-interface interval required here. */
                                delay_ms(500);
                                /* Change the current control-flow path as required by this branch. */
                                goto Year;
                        }
                        /* Access the RTC register or schedule field used by the time/date logic. */
                        YEAR=year;
                }
                /* Test the next mutually exclusive condition when earlier conditions did not match. */
                else if(choice==4)
                {
                        /* Return the computed result to the calling function. */
                        return;
                }
                /* Handle the remaining case when no preceding condition matched. */
                else
                {
                        /* Send the specified instruction to the LCD controller. */
                        Cmdlcd(CLEAR_LCD);
                                /* Display the supplied null-terminated string on the LCD. */
                                Strlcd("invalid option");
                /* Wait for the peripheral settling / user-interface interval required here. */
                delay_ms(100);
                }
        }
}

   /////
   /* Function: labtimeedit; void are used as the function inputs. */
   void labtimeedit(void)
   {
     /* Declare local state used by this routine. */
     u32 choice; 
		 /* Declare local state used by this routine. */
		 u32 second;
     /* Repeat this block while the stated condition remains true. */
     while(1)
         {
        /* Send the specified instruction to the LCD controller. */
        Cmdlcd(CLEAR_LCD);
        /* Display the supplied null-terminated string on the LCD. */
        Strlcd("1.ON TIME       ");
        /* Send the specified instruction to the LCD controller. */
        Cmdlcd(GOTO_LINE2_POS0);
        /* Display the supplied null-terminated string on the LCD. */
        Strlcd("2.OFF TIME 3.EXT");
                /* Read the keypad state / decoded key from the matrix keypad driver. */
                choice=keyscan()-48;
					  /* Wait for the peripheral settling / user-interface interval required here. */
					  delay_ms(100);
 /* Evaluate the condition and execute this branch only when it is true. */
 if(choice==1)
        { 
					/* Repeat this block while the stated condition remains true. */
					while(1)
        {
                /* Send the specified instruction to the LCD controller. */
                Cmdlcd(CLEAR_LCD);
        /* Access the RTC register or schedule field used by the time/date logic. */
        Strlcd("1.HOUR 2.MIN");
        /* Send the specified instruction to the LCD controller. */
        Cmdlcd(GOTO_LINE2_POS0);
        /* Access the RTC register or schedule field used by the time/date logic. */
        Strlcd("3.SEC  4.EXT");

                /* Read the keypad state / decoded key from the matrix keypad driver. */
                choice =keyscan()-48;
					     /* Wait for the peripheral settling / user-interface interval required here. */
					     delay_ms(100);
        /* Evaluate the condition and execute this branch only when it is true. */
        if(choice==1)
        {
                 Hour:
                        /* Send the specified instruction to the LCD controller. */
                        Cmdlcd(CLEAR_LCD);
                        /* Access the RTC register or schedule field used by the time/date logic. */
                        Strlcd("ENTER HOUR");
                        /* Access the RTC register or schedule field used by the time/date logic. */
                        ON_HOUR = ReadNum();
                        /* Evaluate the condition and execute this branch only when it is true. */
                        if(ON_HOUR > 24)
                        {
                                /* Send the specified instruction to the LCD controller. */
                                Cmdlcd(CLEAR_LCD);
                                /* Access the RTC register or schedule field used by the time/date logic. */
                                Strlcd("INVALID HOUR");
                                /* Wait for the peripheral settling / user-interface interval required here. */
                                delay_ms(500);
                                /* Change the current control-flow path as required by this branch. */
                                goto Hour;
                        }
                }
        /* Test the next mutually exclusive condition when earlier conditions did not match. */
        else if(choice==2)
        {
                        Minute:
                        /* Send the specified instruction to the LCD controller. */
                        Cmdlcd(CLEAR_LCD);
                        /* Access the RTC register or schedule field used by the time/date logic. */
                        Strlcd("ENTER MINUTE");
                        /* Access the RTC register or schedule field used by the time/date logic. */
                        ON_MIN= ReadNum();
                        /* Evaluate the condition and execute this branch only when it is true. */
                        if(ON_MIN > 60)
                        {
                                /* Send the specified instruction to the LCD controller. */
                                Cmdlcd(CLEAR_LCD);
                                /* Access the RTC register or schedule field used by the time/date logic. */
                                Strlcd("INVALID MINUTE");
                                /* Wait for the peripheral settling / user-interface interval required here. */
                                delay_ms(500);
                                /* Change the current control-flow path as required by this branch. */
                                goto Minute;
                        }
                }
  /* Test the next mutually exclusive condition when earlier conditions did not match. */
  else if(choice==3)
        {
                        Second:
                        /* Send the specified instruction to the LCD controller. */
                        Cmdlcd(CLEAR_LCD);
                        /* Access the RTC register or schedule field used by the time/date logic. */
                        Strlcd("ENTER SECOND");
                         /* Update the variable with the newly calculated or entered value. */
                         second=ReadNum();
                        /* Evaluate the condition and execute this branch only when it is true. */
                        if(second > 60)
                        {
                                /* Send the specified instruction to the LCD controller. */
                                Cmdlcd(CLEAR_LCD);
                                /* Access the RTC register or schedule field used by the time/date logic. */
                                Strlcd("INVALID SECOND");
                                /* Wait for the peripheral settling / user-interface interval required here. */
                                delay_ms(500);
                                /* Change the current control-flow path as required by this branch. */
                                goto Second;
                        }
                       // SEC=second;
                }
        /* Test the next mutually exclusive condition when earlier conditions did not match. */
        else if(choice==4)
                /* Change the current control-flow path as required by this branch. */
                break;
        /* Handle the remaining case when no preceding condition matched. */
        else
        {
                /* Send the specified instruction to the LCD controller. */
                Cmdlcd(CLEAR_LCD);
                                /* Display the supplied null-terminated string on the LCD. */
                                Strlcd("invalid option");
                /* Wait for the peripheral settling / user-interface interval required here. */
                delay_ms(100);
        }
}
				}
/* Test the next mutually exclusive condition when earlier conditions did not match. */
else if(choice==2)
                {
                        /* Repeat this block while the stated condition remains true. */
                        while(1)
        {
                /* Send the specified instruction to the LCD controller. */
                Cmdlcd(CLEAR_LCD);
        /* Access the RTC register or schedule field used by the time/date logic. */
        Strlcd("1.HOUR  2.MIN");
        /* Send the specified instruction to the LCD controller. */
        Cmdlcd(GOTO_LINE2_POS0);
        /* Access the RTC register or schedule field used by the time/date logic. */
        Strlcd("3.SEC  4.EXT");

                /* Read the keypad state / decoded key from the matrix keypad driver. */
                choice =keyscan()-48;
					     /* Wait for the peripheral settling / user-interface interval required here. */
					     delay_ms(100);
        /* Evaluate the condition and execute this branch only when it is true. */
        if(choice==1)
        {
                 Hour1:
                        /* Send the specified instruction to the LCD controller. */
                        Cmdlcd(CLEAR_LCD);
                        /* Access the RTC register or schedule field used by the time/date logic. */
                        Strlcd("ENTER HOUR");
                        /* Access the RTC register or schedule field used by the time/date logic. */
                        OFF_HOUR= ReadNum();
                        /* Evaluate the condition and execute this branch only when it is true. */
                        if(OFF_HOUR> 24)
                        {
                                /* Send the specified instruction to the LCD controller. */
                                Cmdlcd(CLEAR_LCD);
                                /* Access the RTC register or schedule field used by the time/date logic. */
                                Strlcd("INVALID HOUR");
                                /* Wait for the peripheral settling / user-interface interval required here. */
                                delay_ms(500);
                                /* Change the current control-flow path as required by this branch. */
                                goto Hour1;
                        }
                }
        /* Test the next mutually exclusive condition when earlier conditions did not match. */
        else if(choice==2)
        {
                        Minute1:
                        /* Send the specified instruction to the LCD controller. */
                        Cmdlcd(CLEAR_LCD);
                        /* Access the RTC register or schedule field used by the time/date logic. */
                        Strlcd("ENTER MINUTE");
                        /* Access the RTC register or schedule field used by the time/date logic. */
                        OFF_MIN= ReadNum();
                        /* Evaluate the condition and execute this branch only when it is true. */
                        if(OFF_MIN > 60)
                        {
                                /* Send the specified instruction to the LCD controller. */
                                Cmdlcd(CLEAR_LCD);
                                /* Access the RTC register or schedule field used by the time/date logic. */
                                Strlcd("INVALID MINUTE");
                                /* Wait for the peripheral settling / user-interface interval required here. */
                                delay_ms(500);
                                /* Change the current control-flow path as required by this branch. */
                                goto Minute1;
                        }
                }
  /* Test the next mutually exclusive condition when earlier conditions did not match. */
  else if(choice==3)
        {
                        Second1:
                        /* Send the specified instruction to the LCD controller. */
                        Cmdlcd(CLEAR_LCD);
                        /* Access the RTC register or schedule field used by the time/date logic. */
                        Strlcd("ENTER SECOND");
                         /* Update the variable with the newly calculated or entered value. */
                         second=ReadNum();
                        /* Evaluate the condition and execute this branch only when it is true. */
                        if(second > 60)
                        {
                                /* Send the specified instruction to the LCD controller. */
                                Cmdlcd(CLEAR_LCD);
                                /* Access the RTC register or schedule field used by the time/date logic. */
                                Strlcd("INVALID SECOND");
                                /* Wait for the peripheral settling / user-interface interval required here. */
                                delay_ms(500);
                                /* Change the current control-flow path as required by this branch. */
                                goto Second1;
                        }
                       // SEC=second;
                }
        /* Test the next mutually exclusive condition when earlier conditions did not match. */
        else if(choice==4)
                /* Change the current control-flow path as required by this branch. */
                break;
        /* Handle the remaining case when no preceding condition matched. */
        else
        {
                /* Send the specified instruction to the LCD controller. */
                Cmdlcd(CLEAR_LCD);
                                /* Display the supplied null-terminated string on the LCD. */
                                Strlcd("invalid option");
                /* Wait for the peripheral settling / user-interface interval required here. */
                delay_ms(100);
        }
    }
 }
/* Test the next mutually exclusive condition when earlier conditions did not match. */
else if(choice==3)
                {
                        /* Change the current control-flow path as required by this branch. */
                        break;
                }
     /* Handle the remaining case when no preceding condition matched. */
     else
                {
                        /* Send the specified instruction to the LCD controller. */
                        Cmdlcd(CLEAR_LCD);
                                /* Display the supplied null-terminated string on the LCD. */
                                Strlcd("invalid option");
                /* Wait for the peripheral settling / user-interface interval required here. */
                delay_ms(100);
                }
        }
}
