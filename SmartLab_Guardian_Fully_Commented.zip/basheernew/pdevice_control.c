//device_control.c
#include "headerfiles.h"
#include "device_control.h"

//u32 temp=0,temp1=0;

/* Function: initLED; void are used as the function inputs. */
void initLED(void)
{
    //PINSEL0&=~(3<<10);//p0.5 as GPIO
    //PINSEL0&=~(3<<12);//p0.6 as GPIO

    /* Configure the selected GPIO pin(s) as input or output without changing unrelated direction bits. */
    IODIR1 |= LED_MASK|BUZZER;
	/* Drive the selected GPIO output bit(s) HIGH (IOSET) or LOW (IOCLR). */
	IOCLR1=BUZZER;
    /* Drive the selected GPIO output bit(s) HIGH (IOSET) or LOW (IOCLR). */
    IOCLR1=LED_MASK;
}
/* Function: AllLEDsOFF; void are used as the function inputs. */
void AllLEDsOFF(void)
{
	/* Drive the selected GPIO output bit(s) HIGH (IOSET) or LOW (IOCLR). */
	IOCLR1=LED_MASK;
}
/* Function: AllLEDsON; void are used as the function inputs. */
void AllLEDsON(void)
{
	/* Drive the selected GPIO output bit(s) HIGH (IOSET) or LOW (IOCLR). */
	IOSET1=LED_MASK;
}
/* Function: DeviceCntrl; u32 command,u32 *temp,u32 *temp1 are used as the function inputs. */
void DeviceCntrl(u32 command,u32 *temp,u32 *temp1)
{	 
          /* Select an operation based on the evaluated expression. */
          switch(command)
			{
			  /* Handle this specific switch-case value. */
			  case 1:IOSET1=LED1;
					*temp=1;
				   /* Change the current control-flow path as required by this branch. */
				   break;
			  /* Handle this specific switch-case value. */
			  case 2:IOCLR1=LED1;
			        *temp=0;
					/* Change the current control-flow path as required by this branch. */
					break;
			/* Handle this specific switch-case value. */
			case 3:IOSET1=LED2;
			       *temp1=1;
		           /* Change the current control-flow path as required by this branch. */
		           break;				
				/* Handle this specific switch-case value. */
				case 4:IOCLR1=LED2;
					*temp1=0;
					/* Change the current control-flow path as required by this branch. */
					break;
			/* Handle this specific switch-case value. */
			case 5:AllLEDsON();
			       *temp=1,*temp1=1;
				    /* Change the current control-flow path as required by this branch. */
				    break;
			/* Handle this specific switch-case value. */
			case 6:AllLEDsOFF();
			       *temp=0,*temp1=0;
	            	/* Change the current control-flow path as required by this branch. */
	            	break;
			 /* Handle this specific switch-case value. */
			 case 47:Cmdlcd(CLEAR_LCD);
			         /* Perform the operation required at this point in the routine. */
			         showtime();
			         /* Wait for the peripheral settling / user-interface interval required here. */
			         delay_ms(1000);
					 /* Change the current control-flow path as required by this branch. */
					 break;
}
}
/* Function: devicestatus; u32 temp,u32 temp1 are used as the function inputs. */
void devicestatus(u32 temp,u32 temp1)
{		 			 
	                /* Evaluate the condition and execute this branch only when it is true. */
	                if(temp==1)
					/* Send the specified instruction to the LCD controller. */
					{ Cmdlcd(GOTO_LINE1_POS0);
					/* Display the supplied null-terminated string on the LCD. */
					Strlcd("L1 ON  ");
					}
					/* Handle the remaining case when no preceding condition matched. */
					else
					 {
					 /* Send the specified instruction to the LCD controller. */
					 Cmdlcd(GOTO_LINE1_POS0);
					/* Display the supplied null-terminated string on the LCD. */
					Strlcd("L1 OFF  ");
					}
					/* Evaluate the condition and execute this branch only when it is true. */
					if(temp1==1)
					 {
					 /* Send the specified instruction to the LCD controller. */
					 Cmdlcd(GOTO_LINE1_POS0+8);
					/* Display the supplied null-terminated string on the LCD. */
					Strlcd("L2 ON   ");
					}
					/* Handle the remaining case when no preceding condition matched. */
					else
					 {
					 /* Send the specified instruction to the LCD controller. */
					 Cmdlcd(GOTO_LINE1_POS0+8);
					/* Display the supplied null-terminated string on the LCD. */
					Strlcd("L2 OFF  ");
            		 }
                 /* Send the specified instruction to the LCD controller. */
                 Cmdlcd(GOTO_LINE2_POS0);
	             /* Display the supplied null-terminated string on the LCD. */
	             Strlcd("lab is opened   ");
}

