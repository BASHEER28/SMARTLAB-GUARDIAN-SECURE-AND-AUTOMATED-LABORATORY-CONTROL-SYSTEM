//REAL TIME CLOCK.c program
/********************************************************************************************/
//header file inclusion
#include"headerfiles.h"
#include "rtc.h"
u8 day[][4]={"SUN","MON","TUE","WED","THU","FRI","SAT"}; //day of week register
/* Function: initRTC; void are used as the function inputs. */
void initRTC(void)
{
/*-----------------------------------------------------------------------------------------
 to set require RTC parameters
-----------------------------------------------------------------------------------------*/
/* Evaluate the condition and execute this branch only when it is true. */
if((CCR&0X01)==0)
{
//to enable the RTC by 0th bit set  and give external frequency by set 4th bit
//CCR=1<<1;
/* Access the RTC register or schedule field used by the time/date logic. */
CCR=(1<<0|1<<4);
/* Access the RTC register or schedule field used by the time/date logic. */
HOUR=10;
/* Access the RTC register or schedule field used by the time/date logic. */
MIN=59;
/* Access the RTC register or schedule field used by the time/date logic. */
SEC=30;
/* Access the RTC register or schedule field used by the time/date logic. */
DOM=31;
/* Update the variable with the newly calculated or entered value. */
DOW=4;
/* Access the RTC register or schedule field used by the time/date logic. */
MONTH=11;
/* Access the RTC register or schedule field used by the time/date logic. */
YEAR=2026;
}
/* Handle the remaining case when no preceding condition matched. */
else
/* Access the RTC register or schedule field used by the time/date logic. */
CCR|=1<<4;
}

/* Function: Islabtime; void are used as the function inputs. */
u32 Islabtime(void)
{ 
	/* Evaluate the condition and execute this branch only when it is true. */
	if(((ON_HOUR)*60+ON_MIN)<((OFF_HOUR)*60)+OFF_MIN)
	{
		/* Evaluate the condition and execute this branch only when it is true. */
		if((((HOUR*60)+MIN)>=((ON_HOUR*60)+ON_MIN))&&(((HOUR*60)+MIN)<((OFF_HOUR*60)+OFF_MIN)))
		/* Return the computed result to the calling function. */
		return 1;
	}
 /* Test the next mutually exclusive condition when earlier conditions did not match. */
 else if(((ON_HOUR)*60+ON_MIN)> ((OFF_HOUR)*60)+OFF_MIN)
{
	/* Evaluate the condition and execute this branch only when it is true. */
	if((((HOUR*60)+MIN)>=((ON_HOUR*60)+ON_MIN))||(((HOUR*60)+MIN)<((OFF_HOUR*60)+OFF_MIN)))
	/* Return the computed result to the calling function. */
	return 1;
}
  /* Return the computed result to the calling function. */
  return 0;
}
/* Function: showtime; void are used as the function inputs. */
void showtime(void)
{  		 
		Cmdlcd(GOTO_LINE1_POS0);   //current cur in line1 pos1 in LCD
/* Access the RTC register or schedule field used by the time/date logic. */
Charlcd((HOUR/10)+48);
/* Access the RTC register or schedule field used by the time/date logic. */
Charlcd((HOUR%10)+48);
/* Write one character to the LCD at the current cursor position. */
Charlcd(':');
/* Access the RTC register or schedule field used by the time/date logic. */
Charlcd((MIN/10)+48);
/* Access the RTC register or schedule field used by the time/date logic. */
Charlcd((MIN%10)+48);
/* Write one character to the LCD at the current cursor position. */
Charlcd(':');
/* Access the RTC register or schedule field used by the time/date logic. */
Charlcd((SEC/10)+48);
/* Access the RTC register or schedule field used by the time/date logic. */
Charlcd((SEC%10)+48);
/* Display the supplied null-terminated string on the LCD. */
Strlcd("        ");
}
/* Function: RTC_SetTime; u32 hour, u32 minute, u32 second are used as the function inputs. */
void RTC_SetTime(u32 hour, u32 minute, u32 second)
{
    /* Evaluate the condition and execute this branch only when it is true. */
    if(hour < 24 && minute < 60 && second < 60)
    {
        /* Access the RTC register or schedule field used by the time/date logic. */
        SEC = second;
        /* Access the RTC register or schedule field used by the time/date logic. */
        MIN = minute;
        /* Access the RTC register or schedule field used by the time/date logic. */
        HOUR = hour;
    }
}

/* Function: RTC_SetDate; u32 date, u32 month, u32 year, u32 day are used as the function inputs. */
void RTC_SetDate(u32 date, u32 month, u32 year, u32 day)
{
	/* Evaluate the condition and execute this branch only when it is true. */
	if(date >= 1 && date <= 31 &&
		 month >= 1 && month <= 12 &&
		 year >= 2000 && year <= 2099 &&
		 day <= 6)
	{
			/* Access the RTC register or schedule field used by the time/date logic. */
			DOM = date;
			/* Access the RTC register or schedule field used by the time/date logic. */
			MONTH = month;
			/* Access the RTC register or schedule field used by the time/date logic. */
			YEAR = year;
			/* Update the variable with the newly calculated or entered value. */
			DOW = day;
	}
}
/* Function: displaydate; void are used as the function inputs. */
void displaydate(void)
{
	/* Access the RTC register or schedule field used by the time/date logic. */
	Charlcd((DOM / 10) + 48);
	/* Access the RTC register or schedule field used by the time/date logic. */
	Charlcd((DOM % 10) + 48);
	/* Write one character to the LCD at the current cursor position. */
	Charlcd('-');

	/* Access the RTC register or schedule field used by the time/date logic. */
	Charlcd((MONTH / 10) + 48);
	/* Access the RTC register or schedule field used by the time/date logic. */
	Charlcd((MONTH % 10) + 48);
	/* Write one character to the LCD at the current cursor position. */
	Charlcd('-');

	/* Access the RTC register or schedule field used by the time/date logic. */
	Charlcd((YEAR / 1000) + 48);
	/* Access the RTC register or schedule field used by the time/date logic. */
	Charlcd(((YEAR / 100) % 10) + 48);
	/* Access the RTC register or schedule field used by the time/date logic. */
	Charlcd(((YEAR / 10) % 10) + 48);
	/* Access the RTC register or schedule field used by the time/date logic. */
	Charlcd((YEAR % 10) + 48);
}


/* Function: labtimecheck; void are used as the function inputs. */
void labtimecheck(void)
{
  /* Evaluate the condition and execute this branch only when it is true. */
  if((Islabtime()))
        {  
					
					/* Send the specified instruction to the LCD controller. */
					Cmdlcd(CLEAR_LCD);
					/* Send the specified instruction to the LCD controller. */
					Cmdlcd(0x80);
					/* Display the supplied null-terminated string on the LCD. */
					Strlcd("lab open");
				  /* Wait for the peripheral settling / user-interface interval required here. */
				  delay_ms(1000);
				/* Send the specified instruction to the LCD controller. */
				Cmdlcd(CLEAR_LCD);
            
        }
}

	

