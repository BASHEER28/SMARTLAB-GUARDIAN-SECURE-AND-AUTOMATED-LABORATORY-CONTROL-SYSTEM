//delay.c
#include "types.h"
/* Function: delay_us; u32 dlyus are used as the function inputs. */
void delay_us(u32 dlyus)
{
 /* Run the loop using its initialisation, condition and update expressions. */
 for(dlyus*=12;dlyus>0;dlyus--);
}
/* Function: delay_ms; u32 dlyms are used as the function inputs. */
void delay_ms(u32 dlyms)
{
/* Run the loop using its initialisation, condition and update expressions. */
for(;dlyms>0;dlyms--)
	/* Wait for the peripheral settling / user-interface interval required here. */
	delay_us(1000);
}
/* Function: delay_s; u32 dlys are used as the function inputs. */
void delay_s(u32 dlys)
{
/* Run the loop using its initialisation, condition and update expressions. */
for(;dlys>0;dlys--)
	/* Wait for the peripheral settling / user-interface interval required here. */
	delay_ms(1000);
}



