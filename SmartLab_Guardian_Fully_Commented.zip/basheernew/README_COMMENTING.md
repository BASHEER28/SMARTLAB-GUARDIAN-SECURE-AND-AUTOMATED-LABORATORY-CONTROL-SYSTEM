# SmartLab Guardian – Fully Commented Source

This archive contains the original project source with explanatory comments added throughout
the implementation, including function purposes, control flow, register access, keypad/LCD
operations, RTC handling, and application logic.

## Important
- Existing executable statements have been retained; comments are documentation only.
- Comments describe the apparent purpose of the original code. They do not certify correctness.
- Review hardware-specific assumptions (GPIO mapping, PINSEL, VIC channels, RC5 timing,
  LCD mode, RTC clock configuration) against the exact LPC214x board and wiring.
- Validate boundary checks and timing with the target hardware before deployment.
- The password is compiled into the firmware in the original source; this is suitable only
  for a lab demonstration, not production-grade access control.
