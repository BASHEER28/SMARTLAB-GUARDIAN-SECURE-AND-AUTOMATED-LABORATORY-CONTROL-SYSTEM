//password.h
/* Function: passwordchecking; void are used as the function inputs. */
void passwordchecking(void);
/* Function: passwordcheck; void are used as the function inputs. */
int passwordcheck(void);
