//device_control.h
#include"types.h"
/* Function: initLED; void are used as the function inputs. */
void initLED(void);
/* Function: AllLEDsOFF; void are used as the function inputs. */
void AllLEDsOFF(void);
/* Function: AllLEDsON; void are used as the function inputs. */
void AllLEDsON(void);
/* Function: LEDControl; u8  are used as the function inputs. */
int LEDControl(u8 );
/* Function: DeviceCntrl; u32 ,u32 *,u32 * are used as the function inputs. */
void DeviceCntrl(u32 ,u32 *,u32 *);
/* Function: devicestatus; u32 ,u32  are used as the function inputs. */
void devicestatus(u32 ,u32 );
