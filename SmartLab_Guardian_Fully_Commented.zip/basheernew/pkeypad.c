//keypad.c
#include<LPC214x.h>
#include "keypad.h"
#include "lcd.h"
#include "keypaddefines.h"
#include "LCD_defines.h"
#include "types.h"
#include "delay.h"
/*u8 kpmLUT[4][4]={{0,1,2,3},
                  {4,5,6,7},
                  {8,9,10,11},
                  {12,13,14,15}};*/
/* Declare local state used by this routine. */
u8 kpmLUT[4][4]={{'1','2','3','/'},
                  {'4','5','6','x'},
                  {'7','8','9','-'},
                  /* Update the variable with the newly calculated or entered value. */
                  {'c','0','=','+'}};
/* Function: initkpm; void  are used as the function inputs. */
void initkpm(void )
{
        /* Configure the selected GPIO pin(s) as input or output without changing unrelated direction bits. */
        IODIR1|=1<<ROW0;
         /* Configure the selected GPIO pin(s) as input or output without changing unrelated direction bits. */
         IODIR1|=1<<ROW1;
          /* Configure the selected GPIO pin(s) as input or output without changing unrelated direction bits. */
          IODIR1|=1<<ROW2;
           /* Configure the selected GPIO pin(s) as input or output without changing unrelated direction bits. */
           IODIR1|=1<<ROW3;
}
/* Function: colscan; void  are used as the function inputs. */
int colscan(void )
{
        /* Declare local state used by this routine. */
        int t;
        /* Update the hardware register or GPIO state for the selected operation. */
        t=(((IOPIN1>>COL0)&1)&((IOPIN1>>COL1)&1)&((IOPIN1>>COL2)&1)&((IOPIN1>>COL3)&1));
        /* Return the computed result to the calling function. */
        return t;
}
/* Function: rowcheck; void are used as the function inputs. */
u8 rowcheck(void)
{
    u8 r;                       // Variable initialization

    IOCLR1 = (1 << ROW0);       // Makes ROW0 LOW
    IOSET1 = (1 << ROW1);       // Makes ROW1 HIGH
	  IOSET1 = (1 << ROW2);       // Makes ROW2 HIGH
	  IOSET1 = (1 << ROW3);       // Makes ROW3 HIGH

    if(colscan() == 0)          // Checks a key is pressed in row 0
    {
        r = 0;                  // Stores row as 0
        goto last;              // Jumps to the last section
    }

    IOSET1 = (1 << ROW0);       // Makes ROW0 HIGH  
    IOCLR1 = (1 << ROW1);       // Makes ROW1 LOW
    IOSET1 = (1 << ROW2);       // Makes ROW2 HIGH
		IOSET1 = (1 << ROW3);       // Makes ROW3 HIGH

    if(colscan() == 0)          // Checks a key is pressed in row 1
    {
        r = 1;                  // Stores row as 1
        goto last;              // Jumps to the last section
    }

    IOSET1 = (1 << ROW0);       // Makes ROW0 HIGH
		IOSET1 = (1 << ROW1);       // Makes ROW1 HIGH
    IOCLR1 = (1 << ROW2);       // Makes ROW2 LOW
    IOSET1 = (1 << ROW3);       // Makes ROW3 HIGH

    if(colscan() == 0)          // Checks a key is pressed in row 2
    {
        r = 2;                  // Stores row as 2
        goto last;              // Jumps to the last section
    }

    IOSET1 = (1 << ROW0);       // Makes ROW0 HIGH
		IOSET1 = (1 << ROW1);       // Makes ROW1 HIGH
		IOSET1 = (1 << ROW2);       // Makes ROW2 HIGH
    IOCLR1 = (1 << ROW3);       // Makes ROW3 LOW

    if(colscan() == 0)          // Checks a key is pressed in row 3
    {
        r = 3;                  // Stores row as 3
    }

last:
		// Makes all row pins LOW 
    /* Drive the selected GPIO output bit(s) HIGH (IOSET) or LOW (IOCLR). */
    IOCLR1 = (1 << ROW0);
		/* Drive the selected GPIO output bit(s) HIGH (IOSET) or LOW (IOCLR). */
		IOCLR1 = (1 << ROW1);
		/* Drive the selected GPIO output bit(s) HIGH (IOSET) or LOW (IOCLR). */
		IOCLR1 = (1 << ROW2);
		/* Drive the selected GPIO output bit(s) HIGH (IOSET) or LOW (IOCLR). */
		IOCLR1 = (1 << ROW3);
		
    return r;                   // Returns the row
}
/* Function: colcheck; void are used as the function inputs. */
u8 colcheck(void)
/* Perform the operation required at this point in the routine. */
{ u8 c;
        /* Evaluate the condition and execute this branch only when it is true. */
        if(((IOPIN1>>COL0)&1)==0)
                /* Update the variable with the newly calculated or entered value. */
                c=0;
        /* Test the next mutually exclusive condition when earlier conditions did not match. */
        else if(((IOPIN1>>COL1)&1)==0)
                /* Update the variable with the newly calculated or entered value. */
                c=1;
        /* Test the next mutually exclusive condition when earlier conditions did not match. */
        else if(((IOPIN1>>COL2)&1)==0)
                /* Update the variable with the newly calculated or entered value. */
                c=2 ;
        /* Test the next mutually exclusive condition when earlier conditions did not match. */
        else if(((IOPIN1>>COL3)&1)==0)
                /* Update the variable with the newly calculated or entered value. */
                c=3;
        /* Return the computed result to the calling function. */
        return c;
}
/* Function: keyscan; void are used as the function inputs. */
u8 keyscan(void)
{
        /* Declare local state used by this routine. */
        u8 r,keyv,c;
        /* Repeat this block while the stated condition remains true. */
        while(colscan()); 
        /* Read the keypad state / decoded key from the matrix keypad driver. */
        r=rowcheck();
        /* Read the keypad state / decoded key from the matrix keypad driver. */
        c=colcheck();
        /* Update the variable with the newly calculated or entered value. */
        keyv=kpmLUT[r][c];
	/* Repeat this block while the stated condition remains true. */
	while(!colscan());
	/* Return the computed result to the calling function. */
	return keyv;
}

/* Function: password; u32 passlen are used as the function inputs. */
u32 password(u32 passlen)
/* Update the variable with the newly calculated or entered value. */
{ u32 keyv,sum=0,cnt=0,t=0;
	/* Repeat this block while the stated condition remains true. */
	while(cnt<4)
	{
		/* Read the keypad state / decoded key from the matrix keypad driver. */
		keyv=keyscan();
		/* Evaluate the condition and execute this branch only when it is true. */
		if((keyv>='0')&&(keyv<='9'))
		/* Update the variable with the newly calculated or entered value. */
		{ t=1;
			/* Update the variable with the newly calculated or entered value. */
			sum=(sum*10)+keyv-48;
			/* Send the specified instruction to the LCD controller. */
			Cmdlcd(GOTO_LINE2_POS0+cnt++);
			/* Write one character to the LCD at the current cursor position. */
			Charlcd('*');
			/* Repeat this block while the stated condition remains true. */
			while(colscan()==0);
		}
		/* Test the next mutually exclusive condition when earlier conditions did not match. */
		else if((keyv=='x')&&(t==1))
		/* Send the specified instruction to the LCD controller. */
		{ Cmdlcd(GOTO_LINE2_POS0+(--cnt));
			/* Write one character to the LCD at the current cursor position. */
			Charlcd(' ');
			/* Update the variable with the newly calculated or entered value. */
			sum/=10;
			/* Evaluate the condition and execute this branch only when it is true. */
			if(cnt==0)
				/* Update the variable with the newly calculated or entered value. */
				t=0;
		}
		/* Wait for the peripheral settling / user-interface interval required here. */
		delay_ms(50);
	} 
	/* Return the computed result to the calling function. */
	return sum;
}

/* Function: ReadNum; void are used as the function inputs. */
u32 ReadNum(void)
{
	/* Declare local state used by this routine. */
	u32 keyV,sum=0,t=0;
	/* Repeat this block while the stated condition remains true. */
	while(1)
	{		      
		/* Read the keypad state / decoded key from the matrix keypad driver. */
		keyV=keyscan();
		/* Evaluate the condition and execute this branch only when it is true. */
		if((keyV>='0')&&(keyV<='9'))
		/* Perform the operation required at this point in the routine. */
		{ t++;
			/* Update the variable with the newly calculated or entered value. */
			sum=(sum*10)+(keyV-'0');
			/* Send the specified instruction to the LCD controller. */
			Cmdlcd(GOTO_LINE2_POS0);
			/* Perform the operation required at this point in the routine. */
			u32lcd(sum);
			/* Repeat this block while the stated condition remains true. */
			while(colscan()==0);
		}
		/* Test the next mutually exclusive condition when earlier conditions did not match. */
		else if((keyV=='x')&&(t>0))
		{ 
			/* Update the variable with the newly calculated or entered value. */
			sum/=10;
			/* Send the specified instruction to the LCD controller. */
			Cmdlcd(GOTO_LINE2_POS0+(--t));
			/* Write one character to the LCD at the current cursor position. */
			Charlcd(' ');
			//u32lcd(sum);
			/* Evaluate the condition and execute this branch only when it is true. */
			if(sum==0)
				/* Update the variable with the newly calculated or entered value. */
				t=0;
		}
			/* Test the next mutually exclusive condition when earlier conditions did not match. */
			else if(keyV=='=')
			{
				/* Send the specified instruction to the LCD controller. */
				Cmdlcd(CLEAR_LCD);
			/* Repeat this block while the stated condition remains true. */
			while(colscan()==0);
			/* Change the current control-flow path as required by this branch. */
			break;
			}
			/* Wait for the peripheral settling / user-interface interval required here. */
			delay_ms(100);
		}
	/* Return the computed result to the calling function. */
	return sum;
}

