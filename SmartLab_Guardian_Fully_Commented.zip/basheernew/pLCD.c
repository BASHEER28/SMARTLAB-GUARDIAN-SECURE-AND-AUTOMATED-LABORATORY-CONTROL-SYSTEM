//LCD.c

#include "types.h"
#include <LPC214x.h>
#include "macros.h"
#include "LCD_defines.h"
#include "delay.h"
#include "lcd.h"

/* Function: Writelcd; u8 dat are used as the function inputs. */
void Writelcd(u8 dat)
{
	WRITEBYTE(IOPIN0,LCD_DATA,dat);//IOPIN0=IOPINO&~(oxff<<LCD_DATA))|dat<<LCD_DATA;
	/* Drive the selected GPIO output bit(s) HIGH (IOSET) or LOW (IOCLR). */
	IOCLR0=1<<LCD_RW;
	/* Drive the selected GPIO output bit(s) HIGH (IOSET) or LOW (IOCLR). */
	IOSET0=1<<LCD_EN;
	/* Wait for the peripheral settling / user-interface interval required here. */
	delay_us(1); 
	/* Drive the selected GPIO output bit(s) HIGH (IOSET) or LOW (IOCLR). */
	IOCLR0=1<<LCD_EN;
	/* Wait for the peripheral settling / user-interface interval required here. */
	delay_ms(2);
}
/* Function: Cmdlcd; u8 cmd are used as the function inputs. */
void Cmdlcd(u8 cmd)
{
	/* Drive the selected GPIO output bit(s) HIGH (IOSET) or LOW (IOCLR). */
	IOCLR0=1<<LCD_RS;
	/* Perform the operation required at this point in the routine. */
	Writelcd(cmd);
}
/* Function: Charlcd; u8 asciival are used as the function inputs. */
void Charlcd(u8 asciival)
{
	/* Drive the selected GPIO output bit(s) HIGH (IOSET) or LOW (IOCLR). */
	IOSET0=1<<LCD_RS;
	/* Perform the operation required at this point in the routine. */
	Writelcd(asciival);
}
/* Function: initlcd; void are used as the function inputs. */
void initlcd(void)
{
	/* Configure the selected GPIO pin(s) as input or output without changing unrelated direction bits. */
	IODIR0|=((0xff<<LCD_DATA)|(1<<LCD_RS)|(1<<LCD_RW)|(1<<LCD_EN));
	/* Wait for the peripheral settling / user-interface interval required here. */
	delay_ms(15);
	/* Send the specified instruction to the LCD controller. */
	Cmdlcd(0x30);
	/* Wait for the peripheral settling / user-interface interval required here. */
	delay_ms(4);
	/* Wait for the peripheral settling / user-interface interval required here. */
	delay_us(100);
	/* Send the specified instruction to the LCD controller. */
	Cmdlcd(0x30);
	/* Wait for the peripheral settling / user-interface interval required here. */
	delay_us(100);
	/* Send the specified instruction to the LCD controller. */
	Cmdlcd(0x30);
	/* Send the specified instruction to the LCD controller. */
	Cmdlcd(MODE_8BIT_2LINE);
	/* Send the specified instruction to the LCD controller. */
	Cmdlcd(DSP_ON_CUR_OFF);
	/* Send the specified instruction to the LCD controller. */
	Cmdlcd(CLEAR_LCD);
	/* Send the specified instruction to the LCD controller. */
	Cmdlcd(SHIFT_CUR_RIGHT);
}
/* Function: Strlcd; s8 *s are used as the function inputs. */
void Strlcd(s8 *s)
{
	/* Repeat this block while the stated condition remains true. */
	while(*s)
	{
		/* Write one character to the LCD at the current cursor position. */
		Charlcd(*s);
		s++;}
}
/* Function: u32lcd; u32 n are used as the function inputs. */
void u32lcd(u32 n)
{
	/* Declare local state used by this routine. */
	u8 a[10];
	/* Declare local state used by this routine. */
	s32 i=0;
	/* Evaluate the condition and execute this branch only when it is true. */
	if(n==0)
		{
			/* Write one character to the LCD at the current cursor position. */
			Charlcd('0');
		}
		/* Handle the remaining case when no preceding condition matched. */
		else
			{
				/* Repeat this block while the stated condition remains true. */
				while(n>0)
					{
						/* Update the variable with the newly calculated or entered value. */
						a[i]=(n%10)+48;
						/* Update the variable with the newly calculated or entered value. */
						n/=10;
						/* Perform the operation required at this point in the routine. */
						i++;
					}
					/* Run the loop using its initialisation, condition and update expressions. */
					for(--i;i>=0;i--)
					{
						/* Write one character to the LCD at the current cursor position. */
						Charlcd(a[i]);
					}
			}
}
/* Function: s32lcd; s32 sn are used as the function inputs. */
void s32lcd(s32 sn)
{
	/* Evaluate the condition and execute this branch only when it is true. */
	if(sn<0)
		{
			/* Write one character to the LCD at the current cursor position. */
			Charlcd('-');
			/* Update the variable with the newly calculated or entered value. */
			sn=-sn;
		}
		/* Perform the operation required at this point in the routine. */
		u32lcd(sn);
}
/* Function: f32lcd; f32 FN,u8 nDP are used as the function inputs. */
void f32lcd(f32 FN,u8 nDP)
{
	/* Declare local state used by this routine. */
	u32 n,i;
	/* Evaluate the condition and execute this branch only when it is true. */
	if(FN<0.0)
		{
			/* Write one character to the LCD at the current cursor position. */
			Charlcd('-');
			/* Update the variable with the newly calculated or entered value. */
			FN=-FN;
		}
		/* Update the variable with the newly calculated or entered value. */
		n=FN;
		/* Perform the operation required at this point in the routine. */
		u32lcd(n);
		/* Write one character to the LCD at the current cursor position. */
		Charlcd('.');
		/* Run the loop using its initialisation, condition and update expressions. */
		for(i=0;i<nDP;i++)
		{
			/* Update the variable with the newly calculated or entered value. */
			FN=(FN-n)*10;
			/* Update the variable with the newly calculated or entered value. */
			n=FN;
			/* Write one character to the LCD at the current cursor position. */
			Charlcd(n+48);
		}
}
/* Function: BuildCGRAM; u8 *p,u8 nBytes are used as the function inputs. */
void BuildCGRAM(u8 *p,u8 nBytes)
{
	/* Declare local state used by this routine. */
	u32 i;
	/* Send the specified instruction to the LCD controller. */
	Cmdlcd(GOTO_CGRAM_START);
	/* Drive the selected GPIO output bit(s) HIGH (IOSET) or LOW (IOCLR). */
	IOCLR0=1<<LCD_RW;
	/* Run the loop using its initialisation, condition and update expressions. */
	for(i=0;i<nBytes;i++)
	{
		/* Perform the operation required at this point in the routine. */
		Writelcd(p[i]);
	}
	/* Send the specified instruction to the LCD controller. */
	Cmdlcd(GOTO_LINE1_POS0);
}





