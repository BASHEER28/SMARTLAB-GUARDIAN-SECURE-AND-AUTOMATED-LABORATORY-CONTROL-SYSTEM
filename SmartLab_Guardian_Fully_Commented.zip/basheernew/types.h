//types.h
/* Perform the operation required at this point in the routine. */
typedef unsigned int u32;
/* Perform the operation required at this point in the routine. */
typedef unsigned char u8;
/* Perform the operation required at this point in the routine. */
typedef const char c8;
/* Perform the operation required at this point in the routine. */
typedef char s8;
/* Perform the operation required at this point in the routine. */
typedef int s32;
/* Perform the operation required at this point in the routine. */
typedef float f32;


