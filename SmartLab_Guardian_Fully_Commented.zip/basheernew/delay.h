//delay.h
#include "types.h"
/* Function: delay_us; u32 dlyus are used as the function inputs. */
void delay_us(u32 dlyus);
/* Function: delay_ms; u32 dlyms are used as the function inputs. */
void delay_ms(u32 dlyms);
/* Function: delay_s; u32 dlys are used as the function inputs. */
void delay_s(u32 dlys);


